
$(function(){
	//导航栏部分
	$('.menu-item').hover(function(){
		$('#shop-nav').css({'overflow':'visible'});
	},function(){
		$('#shop-nav').css({'overflow':'hidden'});
	});
});